import mitt from 'mitt';

export const mitter = mitt();